AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

-- Server-side NextBot execution layer for D3bot NPC
-- Translates D3bot AI/navigation intents into NextBot locomotion, jumping, crouching,
-- wall climbing, trajectory pouncing, flying intermission Crows, doors/barricades, and ZS projectiles.

local function pickRandomSound(tbl)
	if not istable(tbl) or #tbl == 0 then return nil end
	return tbl[math.random(1, #tbl)]
end

local scratchMeleeMin, scratchMeleeMax = Vector(-4, -4, -4), Vector(4, 4, 4)
local scratchPounceMin, scratchPounceMax = Vector(-12, -12, -12), Vector(12, 12, 12)
local scratchStartVec, scratchEndVec = Vector(), Vector()
local activeFilterNpc = nil

local function npcNonAllyFilter(ent)
	if ent == activeFilterNpc or ent.IsD3botNPC then return false end
	if ent:IsPlayer() and ent:Team() == (TEAM_UNDEAD or 3) then return false end
	return true
end

local standUpTrData = {
	start = scratchStartVec,
	endpos = scratchEndVec,
	filter = npcNonAllyFilter,
	mask = MASK_NPCSOLID
}

local meleeTrData = {
	start = scratchStartVec,
	endpos = scratchEndVec,
	mins = scratchMeleeMin,
	maxs = scratchMeleeMax,
	filter = npcNonAllyFilter,
	mask = MASK_SHOT
}

local pounceTrData = {
	start = scratchStartVec,
	endpos = scratchEndVec,
	mins = scratchPounceMin,
	maxs = scratchPounceMax,
	filter = npcNonAllyFilter,
	mask = MASK_SHOT
}

function ENT:EmitClassSound(category, level, pitchOffset)
	local cfg = self:GetClassConfig()
	local snd = cfg and cfg.Sounds and pickRandomSound(cfg.Sounds[category])
	if not snd then return end
	local basePitch = math.Clamp(math.Round((cfg.VoicePitch or 0.7) * 140) + (pitchOffset or 0), 50, 160)
	self:EmitSound(snd, level or 75, math.random(basePitch - 6, basePitch + 6), 0.9, CHAN_VOICE)
end

function ENT:PlaySafeActivity(act, fallbackSeqName)
	if self:GetActivity() == act and act ~= ACT_INVALID then
		return
	end
	local seq = (act and act ~= ACT_INVALID) and self:SelectWeightedSequence(act) or -1
	if seq and seq >= 0 then
		self:StartActivity(act)
		return
	end
	if fallbackSeqName then
		local fbSeq = self:LookupSequence(fallbackSeqName)
		if fbSeq and fbSeq >= 0 then
			self:ResetSequence(fbSeq)
			return
		end
	end
	if act and act ~= ACT_INVALID then
		self:StartActivity(act)
	end
end

function ENT:ApplyZombieClass(classNameOrQuery)
	local resolved = D3botNPC.ResolveClassName(classNameOrQuery) or "Zombie"
	local cfg = D3botNPC.GetClassConfig(resolved)

	self:SetNPCClassName(cfg.Name)
	self:SetNPCCrow(cfg.IsCrow == true)
	self.PendingZombieClass = cfg.Name
	self.m_ClassConfig = cfg
	if not cfg.IsCrow then
		self.m_NonCrowClass = cfg.Name
	end

	local mdl = cfg.Model
	if not util.IsValidModel(mdl) then
		mdl = cfg.FallbackModel or "models/player/zombie_classic.mdl"
	end
	self:SetModel(mdl)
	local scale = cfg.ModelScale or 1
	self:SetModelScale(scale, 0)

	self:SetMaxHealth(cfg.Health or 225)
	self:SetHealth(cfg.Health or 225)
	self:SetBloodColor(cfg.BloodColor or BLOOD_COLOR_RED)

	if cfg.RenderMode and cfg.RenderMode ~= RENDERMODE_NORMAL then
		self:SetRenderMode(cfg.RenderMode)
		self:SetColor(Color(255, 255, 255, cfg.Alpha or 55))
		self:DrawShadow(false)
	else
		self:SetRenderMode(RENDERMODE_NORMAL)
		self:SetColor(Color(255, 255, 255, 255))
		self:DrawShadow(true)
	end

	if cfg.IsCrow then
		self:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
	else
		self:SetCollisionGroup(COLLISION_GROUP_NPC)
	end
	self:CollisionRulesChanged()

	local hullMin, hullMax = self:GetHull()
	local duckMin, duckMax = self:GetHullDuck()
	self.m_CachedHullMin = hullMin
	self.m_CachedHullMax = hullMax
	self.m_CachedHullDuckMin = duckMin
	self.m_CachedHullDuckMax = duckMax
	self:SetCollisionBounds(hullMin, hullMax)

	if self.loco then
		self.loco:SetDesiredSpeed(cfg.RunSpeed or 175)
		self.loco:SetAcceleration(math.max(550, (cfg.RunSpeed or 175) * 4.8))
		self.loco:SetDeceleration(math.max(650, (cfg.RunSpeed or 175) * 5.8))
		self.loco:SetStepHeight(math.max(cfg.StepSize or 18, 20))
		self.loco:SetJumpHeight(math.max(52, ((cfg.JumpPower or 200) ^ 2) / 1200 + 22))
		self.loco:SetDeathDropHeight(cfg.NoFallDamage and 1800 or 450)
	end

	local slot = self.D3bot_RosterSlot
	if slot then
		slot.ZombieClass = cfg.Name
		slot.IsCrow = cfg.IsCrow == true
		if not cfg.IsCrow then
			slot.DeathClass = cfg.Name
		end
		if D3botNPC.Roster and D3botNPC.Roster.ScheduleSync then
			D3botNPC.Roster.ScheduleSync()
		end
	end

	D3botNPC.AI.InitializeOrReset(self)
end

function ENT:MorphToCrow()
	if self:IsCrow() then return end
	local slot = self.D3bot_RosterSlot
	local curClass = self:GetClassConfig().Name
	if slot then
		slot.DeathClass = curClass
	end
	self.m_NonCrowClass = curClass
	self:ApplyZombieClass("Crow")
	self:SetNPCCrouching(false)
	-- Launch briefly upward so crows lift off dramatically on wave end
	if self.loco and self:IsOnGround() then
		self.loco:Jump()
	end
end

function ENT:RestoreFromCrow(overrideClassName)
	local targetClass = overrideClassName
		or (self.D3bot_RosterSlot and self.D3bot_RosterSlot.ForcedClass)
		or (self.D3bot_RosterSlot and self.D3bot_RosterSlot.DeathClass)
		or self.m_NonCrowClass
		or "Zombie"

	local cfg = D3botNPC.GetClassConfig(targetClass)
	if not cfg or cfg.IsCrow then
		cfg = D3botNPC.Population and D3botNPC.Population.SelectSpawnClass() or D3botNPC.GetClassConfig("Zombie")
	end

	local spawnPos, spawnAng = D3botNPC.ZS.SelectZombieSpawnPos(cfg)
	if spawnPos then
		self:SetPos(spawnPos)
		if spawnAng then
			self:SetAngles(spawnAng)
		end
	end

	self:SetNPCCrouching(false)
	self:ApplyZombieClass(cfg.Name)
	D3botNPC.AI.RerollTarget(self)
	D3botNPC.AI.UpdatePathImmediate(self)
end

function ENT:Initialize()
	self:SetNPCLiving(true)
	self:SetNPCCrouching(false)
	self:SetNPCAggroAlpha(false)
	self:SetNPCCrow(false)
	self:SetNPCTeam(TEAM_UNDEAD or 3)
	self:SetNextPounceTime(0)
	self:SetNextRangedTime(0)

	self:SetHealth(225)
	self:SetMaxHealth(225)
	self:SetSolid(SOLID_BBOX)
	self:SetCollisionGroup(COLLISION_GROUP_NPC)
	self:SetCustomCollisionCheck(true)
	self:CollisionRulesChanged()
	self:SetLagCompensated(true)

	self.DamagedBy = {}
	self.m_EyeAngles = self:GetAngles()
	self.m_NextAttackTime = 0
	self.m_NextIdleSound = CurTime() + math.Rand(3, 8)
	self.m_NextPosStore = CurTime() + 0.5
	self.m_CurrentActivity = ACT_INVALID
	self.m_LegDamageEnd = nil

	self:ApplyZombieClass(self.PendingZombieClass or "Zombie")

	if self.PendingRosterSlot and D3botNPC.Roster and D3botNPC.Roster.BindEntity then
		D3botNPC.Roster.BindEntity(self.PendingRosterSlot, self)
	elseif self.PendingBotName then
		self:SetNPCName(self.PendingBotName)
	end

	D3botNPC.RegisterNPC(self)
end

function ENT:OnRemove()
	D3botNPC.UnregisterNPC(self)
	if not self.m_DeadProcessed and not self.m_RosterRemoved and D3botNPC.Roster and D3botNPC.Roster.UnbindEntityOnDeath then
		D3botNPC.Roster.UnbindEntityOnDeath(self)
	end
end

function ENT:CanStandUp()
	local standMin = self.m_CachedHullMin
	local standMax = self.m_CachedHullMax
	if not standMin then
		standMin, standMax = self:GetHull()
		self.m_CachedHullMin, self.m_CachedHullMax = standMin, standMax
	end
	local p = self:GetPos()
	scratchStartVec:SetUnpacked(p.x, p.y, p.z)
	scratchEndVec:SetUnpacked(p.x, p.y, p.z + 2)
	standUpTrData.mins = standMin
	standUpTrData.maxs = standMax
	activeFilterNpc = self
	local tr = util.TraceHull(standUpTrData)
	activeFilterNpc = nil
	return not tr.Hit
end

function ENT:UpdateCrouchState(wantDuck)
	local cfg = self:GetClassConfig()
	if cfg.CantDuck then wantDuck = false end

	local isCrouching = self:GetNPCCrouching()
	if wantDuck and not isCrouching then
		self:SetNPCCrouching(true)
		if not self.m_CachedHullDuckMin then
			self.m_CachedHullDuckMin, self.m_CachedHullDuckMax = self:GetHullDuck()
		end
		self:SetCollisionBounds(self.m_CachedHullDuckMin, self.m_CachedHullDuckMax)
	elseif not wantDuck and isCrouching then
		if self:CanStandUp() then
			self:SetNPCCrouching(false)
			if not self.m_CachedHullMin then
				self.m_CachedHullMin, self.m_CachedHullMax = self:GetHull()
			end
			self:SetCollisionBounds(self.m_CachedHullMin, self.m_CachedHullMax)
		end
	end
end

function ENT:TryOpenOrBreakDoor(ent)
	if not IsValid(ent) then return false end
	local cls = ent:GetClass()
	if cls ~= "prop_door_rotating" and cls ~= "func_door" and cls ~= "func_door_rotating" then
		return false
	end
	if self:IsCrow() then return false end
	if ent.IsNailed and ent:IsNailed() then return false end

	-- Try opening unlocked door cleanly once per cooldown
	if (not ent.D3botNPC_NextDoorUse or ent.D3botNPC_NextDoorUse < CurTime()) and not ent:GetInternalVariable("m_bLocked") then
		ent.D3botNPC_NextDoorUse = CurTime() + 1.4
		ent:Fire("Open", "", 0, self, self)
		return true
	end
	return false
end

function ENT:DoMeleeImpact(preferredTarget)
	if not IsValid(self) or not self:Alive() then return end

	local cfg = self:GetClassConfig()
	local origin = self:GetShootPos()
	local aimDir = self:GetAimVector()
	local reach = cfg.AttackRange or 48
	local dmgAmount = cfg.Damage or 35
	local dmgType = cfg.DamageType or DMG_SLASH
	local mSize = cfg.MeleeSize or 4.5

	scratchStartVec:SetUnpacked(origin.x, origin.y, origin.z)
	scratchEndVec:SetUnpacked(origin.x + aimDir.x * reach, origin.y + aimDir.y * reach, origin.z + aimDir.z * reach)
	scratchMeleeMin:SetUnpacked(-mSize, -mSize, -mSize)
	scratchMeleeMax:SetUnpacked(mSize, mSize, mSize)
	activeFilterNpc = self
	local tr = util.TraceHull(meleeTrData)
	activeFilterNpc = nil

	local hitEnt = tr.Entity
	if not IsValid(hitEnt) and IsValid(preferredTarget) and origin:DistToSqr(preferredTarget:WorldSpaceCenter()) <= (reach + 14) ^ 2 then
		hitEnt = preferredTarget
	end

	if IsValid(hitEnt) or tr.HitWorld then
		if IsValid(hitEnt) then
			self:EmitClassSound("Hit", 75)

			local dmgPos = (tr.HitPos and tr.HitPos ~= vector_origin) and tr.HitPos or hitEnt:WorldSpaceCenter()
			local dmginfo = DamageInfo()
			dmginfo:SetDamage(dmgAmount)
			dmginfo:SetAttacker(self)
			dmginfo:SetInflictor(self)
			dmginfo:SetDamageType(dmgType)
			dmginfo:SetDamagePosition(dmgPos)
			dmginfo:SetDamageForce(aimDir * dmgAmount * 220 * (cfg.MeleeForceScale or 1))

			-- Handle nailed ZS barricades cleanly
			if hitEnt.IsNailed and hitEnt:IsNailed() and hitEnt.DamageNails then
				hitEnt:DamageNails(self, self, dmgAmount, dmginfo)
			elseif hitEnt.TakeDamageInfo then
				hitEnt:TakeDamageInfo(dmginfo)
			end

			if hitEnt:IsPlayer() and hitEnt:Team() == TEAM_HUMAN then
				self.D3bot_LastDamage = CurTime()
				if cfg.OnMeleeHitHuman then
					pcall(cfg.OnMeleeHitHuman, self, hitEnt, dmgAmount, tr, cfg)
				end
				if cfg.UsePoisonDamage and hitEnt.AddPoisonDamage then
					hitEnt:AddPoisonDamage(dmgAmount * 0.25, self)
				end
			end

			local cls = hitEnt:GetClass()
			if cls == "prop_door_rotating" or cls == "func_door_rotating" then
				hitEnt:EmitSound("physics/wood/wood_box_break" .. math.random(1, 2) .. ".wav", 75)
			end
		else
			self:EmitClassSound("Miss", 72)
		end
	else
		self:EmitClassSound("Miss", 72)
	end
end

function ENT:TryMeleeAttack(preferredTarget)
	local ct = CurTime()
	if ct < (self.m_NextAttackTime or 0) then return false end

	if IsValid(preferredTarget) and self:TryOpenOrBreakDoor(preferredTarget) then
		-- Also proceed with swing if nailed/locked
		if not (preferredTarget.IsNailed and preferredTarget:IsNailed()) and not preferredTarget:GetInternalVariable("m_bLocked") then
			self.m_NextAttackTime = ct + 0.5
			return true
		end
	end

	local cfg = self:GetClassConfig()
	self.m_NextAttackTime = ct + (cfg.AttackCooldown or 1.2)
	self:SetNPCAggroAlpha(true)
	timer.Simple(0.6, function()
		if IsValid(self) then
			self:SetNPCAggroAlpha(false)
		end
	end)

	self:EmitClassSound("Attack", 78)

	local gesture = cfg.Animations and cfg.Animations.AttackGesture or ACT_GMOD_GESTURE_RANGE_ZOMBIE
	if gesture then
		self:RestartGesture(gesture)
	end

	local windup = math.Clamp(cfg.AttackDelay or 0.45, 0.05, 1.0)
	timer.Simple(windup, function()
		if IsValid(self) and self:Alive() then
			self:DoMeleeImpact(preferredTarget)
		end
	end)

	return true
end

function ENT:TryRangedAttack(target)
	local ct = CurTime()
	if ct < self:GetNextRangedTime() then return false end

	local cfg = self:GetClassConfig()
	local r = cfg.RangedAttack
	if not r or not r.Projectile or not IsValid(target) then return false end

	self:SetNextRangedTime(ct + (r.Cooldown or 4.5))
	self:EmitSound(r.CastSound or "npc/fast_zombie/leap1.wav", 78)

	local gesture = cfg.Animations and (cfg.Animations.RangedGesture or cfg.Animations.AttackGesture)
	if gesture then
		self:RestartGesture(gesture)
	end

	timer.Simple(r.Windup or 0.65, function()
		if not IsValid(self) or not self:Alive() or not IsValid(target) then return end

		local startPos = self:GetShootPos()
		local targetPos = target:IsPlayer() and LerpVector(0.65, target:GetPos(), target:EyePos()) or target:WorldSpaceCenter()
		local baseAng = (targetPos - startPos):Angle()

		local sx = r.SpreadScaleX or r.SpreadScale or 6
		local sy = r.SpreadScaleY or r.SpreadScale or 4

		for _, offset in ipairs(r.Spread or { { 0, 0 } }) do
			local ent = ents.Create(r.Projectile)
			if IsValid(ent) then
				local ang = Angle(baseAng.p + (offset[2] or 0) * sy - 4, baseAng.y + (offset[1] or 0) * sx, 0)
				ent:SetPos(startPos + ang:Forward() * 14)
				ent:SetAngles(ang)
				ent:SetOwner(self)
				ent.Team = function() return TEAM_UNDEAD end
				ent:Spawn()
				local phys = ent:GetPhysicsObject()
				if IsValid(phys) then
					phys:Wake()
					phys:SetVelocityInstantaneous(ang:Forward() * (r.Speed or 500) + Vector(0, 0, 60))
				end
			end
		end
	end)

	return true
end

function ENT:ExecutePounce(pounceInfo)
	if not pounceInfo then return end
	local cfg = self:GetClassConfig()

	if pounceInfo.triggerNow then
		self:SetNextPounceTime(CurTime() + (cfg.PounceDelay or 1.25))
		self:EmitClassSound("PounceStart", 78)

		local gesture = cfg.Animations and (cfg.Animations.LeapStart or cfg.Animations.AttackGesture)
		if gesture then
			self:RestartGesture(gesture)
		end

		local startDelay = cfg.PounceStartDelay or 0.45
		local launchAngle = pounceInfo.aimAngle
		self:SetEyeAngles(launchAngle)

		timer.Simple(startDelay, function()
			if not IsValid(self) or not self:Alive() then return end
			self:EmitClassSound("Pounce", 82)
			local maxLeg = (GAMEMODE and GAMEMODE.MaxLegDamage) or 3
			local legFrac = math.Clamp(self:GetLegDamage() / math.max(maxLeg, 1), 0, 1)
			local speed = (1 - 0.5 * legFrac) * (cfg.PounceVelocity or 600)
			local vel = launchAngle:Forward() * speed
			if vel.z < 140 then vel.z = math.max(vel.z, 190) end
			self.loco:Jump()
			self.loco:SetVelocity(vel)
			self.m_ActivePounceUntil = CurTime() + 1.35
			self.m_NextPounceHitCheck = CurTime() + 0.08
		end)
	end
end

function ENT:CheckMidAirPounceImpact()
	local ct = CurTime()
	if not self.m_ActivePounceUntil or ct > self.m_ActivePounceUntil then return end
	if ct < (self.m_NextPounceHitCheck or 0) then return end
	self.m_NextPounceHitCheck = ct + 0.06

	local cfg = self:GetClassConfig()
	local reach = cfg.PounceReach or 24
	local size = cfg.PounceSize or 12
	local origin = self:WorldSpaceCenter()
	local dir = self:GetAimVector()

	scratchStartVec:SetUnpacked(origin.x, origin.y, origin.z)
	scratchEndVec:SetUnpacked(origin.x + dir.x * reach, origin.y + dir.y * reach, origin.z + dir.z * reach)
	scratchPounceMin:SetUnpacked(-size, -size, -size)
	scratchPounceMax:SetUnpacked(size, size, size)
	activeFilterNpc = self
	local tr = util.TraceHull(pounceTrData)
	activeFilterNpc = nil

	if tr.Hit and IsValid(tr.Entity) then
		self.m_ActivePounceUntil = nil
		local ent = tr.Entity
		local dmg = cfg.PounceDamage or 16
		if ent:IsPlayer() then
			dmg = dmg * (cfg.PounceDamageVsPlayerMul or 1)
		end

		local dmginfo = DamageInfo()
		dmginfo:SetDamage(dmg)
		dmginfo:SetAttacker(self)
		dmginfo:SetInflictor(self)
		dmginfo:SetDamageType(DMG_SLASH)
		dmginfo:SetDamagePosition(tr.HitPos)
		dmginfo:SetDamageForce(dir * dmg * 200)

		if ent.IsNailed and ent:IsNailed() and ent.DamageNails then
			ent:DamageNails(self, self, dmg, dmginfo)
		elseif ent.TakeDamageInfo then
			ent:TakeDamageInfo(dmginfo)
		end

		if ent:IsPlayer() and ent:Team() == TEAM_HUMAN then
			self.D3bot_LastDamage = ct
		end
		self:EmitClassSound("Hit", 75)
	end
end

function ENT:ExecuteClimb(targetPos)
	if not targetPos then return end
	local cfg = self:GetClassConfig()
	local myPos = self:GetPos()
	local dir2D = Vector(targetPos.x - myPos.x, targetPos.y - myPos.y, 0)
	if dir2D:LengthSqr() > 4 then
		dir2D:Normalize()
	else
		dir2D = self:GetForward()
	end

	if self:IsOnGround() and self.loco then
		self.loco:Jump()
	end

	local dz = targetPos.z - myPos.z
	local upSpeed = (dz > 18) and (cfg.ClimbSpeed or 220) or 90
	local fwdSpeed = (dz > 28) and 115 or 175
	local climbVel = dir2D * fwdSpeed + Vector(0, 0, upSpeed)
	if self.loco then
		self.loco:SetVelocity(climbVel)
	end
	self.m_IsClimbingUntil = CurTime() + 0.18
end

function ENT:ExecuteCrowFlight(movePos, shouldFlap)
	local cfg = self:GetClassConfig()
	local flySpeed = cfg.FlyingSpeed or 340
	local myPos = self:GetPos()
	local dir = (movePos - myPos)
	local len = dir:Length()
	if len > 2 then
		dir = dir / len
	else
		dir = self:GetForward()
	end

	if shouldFlap and self:IsOnGround() then
		self.loco:Jump()
	end

	if not self:IsOnGround() then
		local curVel = self.loco:GetVelocity()
		local targetZ = math.Clamp((movePos.z - myPos.z) * 1.4, -140, 200)
		local targetVel = Vector(dir.x * flySpeed, dir.y * flySpeed, targetZ)
		local blended = LerpVector(0.18, curVel, targetVel)
		self.loco:SetVelocity(blended)
	end
end

function ENT:BodyUpdate()
	local cfg = self:GetClassConfig()
	local anims = cfg.Animations or {}
	local vel = self.loco and self.loco:GetVelocity() or self:GetVelocity()
	local speed = vel:Length2D()
	local ct = CurTime()

	local targetAct = anims.Idle or ACT_HL2MP_IDLE_ZOMBIE
	local fallbackSeq = anims.SeqIdle

	if cfg.IsCrow then
		if not self:IsOnGround() then
			targetAct = anims.Fly or ACT_FLY
			fallbackSeq = anims.SeqFly or "Fly01"
		elseif speed > 10 then
			targetAct = anims.Run or ACT_RUN
			fallbackSeq = anims.SeqRun or "Run"
		else
			targetAct = anims.Idle or ACT_IDLE
			fallbackSeq = anims.SeqIdle or "Idle01"
		end
	elseif self.m_IsClimbingUntil and ct < self.m_IsClimbingUntil and anims.Climb then
		targetAct = anims.Climb
	elseif not self:IsOnGround() then
		if self.m_ActivePounceUntil and ct < self.m_ActivePounceUntil and anims.Leaping then
			targetAct = anims.Leaping
		else
			targetAct = anims.Jump or anims.Idle or ACT_HL2MP_JUMP_ZOMBIE
		end
	elseif self:Crouching() then
		if speed > 15 then
			targetAct = anims.CrouchWalk or anims.Walk or targetAct
		else
			targetAct = anims.CrouchIdle or anims.Idle or targetAct
		end
	elseif speed > 15 then
		targetAct = (speed > (cfg.WalkSpeed or 110)) and (anims.Run or anims.Walk or targetAct) or (anims.Walk or anims.Run or targetAct)
	end

	self:PlaySafeActivity(targetAct, fallbackSeq)

	-- Drive 2D move & aim pose parameters cleanly for humanoid zombie models
	local maxSpd = math.max(self:GetMaxSpeed(), 1)
	local fwd = self:GetForward():Dot(vel) / maxSpd
	local right = self:GetRight():Dot(vel) / maxSpd
	self:SetPoseParameter("move_x", math.Clamp(fwd, -1, 1))
	self:SetPoseParameter("move_y", math.Clamp(right, -1, 1))

	local eyeAng = self:EyeAngles()
	local entAng = self:GetAngles()
	local pitch = math.NormalizeAngle(eyeAng.p)
	local yawDiff = math.NormalizeAngle(eyeAng.y - entAng.y)
	self:SetPoseParameter("aim_pitch", math.Clamp(pitch, -65, 65))
	self:SetPoseParameter("aim_yaw", math.Clamp(yawDiff, -60, 60))

	self:FrameAdvance()
end

function ENT:OnStuck()
	if D3botNPC and D3botNPC.AI and D3botNPC.AI.NotifyNextBotStuck then
		D3botNPC.AI.NotifyNextBotStuck(self)
	end
	if self.loco and self.loco.ClearStuck then
		self.loco:ClearStuck()
	end
end

function ENT:OnUnStuck()
	if self.D3bot_Mem then
		self.D3bot_Mem.NextBotStuckFlag = false
	end
end

function ENT:OnLandOnGround(ent)
	if self.D3bot_Mem then
		if self.D3bot_Mem.pouncing then
			self.D3bot_Mem.pouncing = false
			self.D3bot_Mem.pounceFlightTime = nil
		end
		if D3botNPC and D3botNPC.AI and D3botNPC.AI.UpdatePathProgress then
			D3botNPC.AI.UpdatePathProgress(self)
		end
	end
	self.m_ActivePounceUntil = nil
end

function ENT:RunBehaviour()
	local faceVec = self.m_FaceVec or Vector()
	self.m_FaceVec = faceVec

	while IsValid(self) and self:Alive() do
		local ct = CurTime()

		if ct >= (self.m_NextIdleSound or 0) then
			self.m_NextIdleSound = ct + math.Rand(5, 11)
			self:EmitClassSound("Idle", 68)
		end

		self:CheckMidAirPounceImpact()

		local intent = D3botNPC.AI.EvaluateStep(self)

		if intent.aimAngle then
			self:SetEyeAngles(intent.aimAngle)
		end

		self:UpdateCrouchState(intent.shouldDuck)

		if intent.pounce and intent.pounce.active then
			self:ExecutePounce(intent.pounce)
		elseif intent.hasDestination and intent.movePos then
			local mPos = intent.movePos
			local myPos = self:GetPos()
			faceVec:SetUnpacked(mPos.x, mPos.y, myPos.z)
			self.loco:SetDesiredSpeed(intent.desiredSpeed or 175)
			self.loco:FaceTowards(faceVec)
			self.loco:Approach(mPos, 1)

			if self:IsCrow() then
				self:ExecuteCrowFlight(mPos, intent.shouldJump)
			elseif intent.shouldJump and self:IsOnGround() then
				self.loco:Jump()
			end

			if intent.shouldClimb and intent.climbTargetPos then
				self:ExecuteClimb(intent.climbTargetPos)
			end

			if intent.shouldRanged and IsValid(intent.attackTarget) then
				self:TryRangedAttack(intent.attackTarget)
			end

			if intent.shouldAttack then
				self:TryMeleeAttack(intent.attackTarget)
			end
		end

		coroutine.yield()
	end
end

function ENT:OnTraceAttack(dmginfo, dir, trace)
	self.m_LastHitGroup = trace and trace.HitGroup or HITGROUP_GENERIC
	local cfg = self:GetClassConfig()

	if self.m_LastHitGroup == HITGROUP_HEAD and not cfg.NoHeadbox then
		local inf = dmginfo:GetInflictor()
		local hsMul = (IsValid(inf) and inf.HeadshotMulti) or 2
		dmginfo:ScaleDamage(hsMul)
	elseif not cfg.IsCrow and (self.m_LastHitGroup == HITGROUP_LEFTLEG or self.m_LastHitGroup == HITGROUP_RIGHTLEG) then
		dmginfo:ScaleDamage(0.5)
		self:AddLegDamage(1.5)
	end
end

function ENT:OnInjured(dmginfo)
	if not IsValid(self) or not self:Alive() then return end

	local ct = CurTime()
	if ct >= (self.m_NextPainSound or 0) then
		self.m_NextPainSound = ct + 0.55
		self:EmitClassSound("Pain", 75)
	end

	local attacker = dmginfo:GetAttacker()
	if D3botNPC.AI.CanBeTgt(self, attacker) and self.D3bot_Mem then
		local curTgt = self.D3bot_Mem.TgtOrNil
		if not IsValid(curTgt) or curTgt:GetPos():DistToSqr(self:GetPos()) > (D3botNPC.AI.BotTgtFixationDistMin ^ 2) then
			D3botNPC.AI.SetTgtOrNil(self, attacker, false, nil)
		end
	end
end

function ENT:OnKilled(dmginfo)
	if self.m_DeadProcessed then return end
	self.m_DeadProcessed = true
	self:SetNPCLiving(false)
	D3botNPC.UnregisterNPC(self)

	if D3botNPC.Roster and D3botNPC.Roster.UnbindEntityOnDeath then
		D3botNPC.Roster.UnbindEntityOnDeath(self)
	end

	-- Silent stuck/admin recycle: clean respawn without fake death sound, scoreboard death, or ragdoll
	if self.m_SilentRecycle then
		hook.Run("D3botNPC_OnZombieKilled", self, nil, nil, dmginfo, nil, false)
		SafeRemoveEntity(self)
		return
	end

	self:EmitClassSound("Death", 78)
	D3botNPC.ZS.OnNPCZombieKilled(self, dmginfo)

	local gib = dmginfo and dmginfo:IsDamageType(DMG_ALWAYSGIB)
	local ragLife = D3botNPC.ConVars.RagdollLifetime and D3botNPC.ConVars.RagdollLifetime:GetFloat() or 8

	if self:IsCrow() then
		ragLife = math.min(ragLife, 3)
	end

	if not gib and ragLife > 0 then
		local rag = ents.Create("prop_ragdoll")
		if IsValid(rag) then
			rag:SetModel(self:GetModel())
			rag:SetPos(self:GetPos())
			rag:SetAngles(self:GetAngles())
			rag:SetSkin(self:GetSkin() or 0)
			rag:SetModelScale(self:GetModelScale() or 1, 0)
			rag:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
			rag:Spawn()

			local force = dmginfo and dmginfo:GetDamageForce() or vector_origin
			for i = 0, rag:GetPhysicsObjectCount() - 1 do
				local phys = rag:GetPhysicsObjectNum(i)
				if IsValid(phys) then
					phys:ApplyForceCenter(force * 0.15)
				end
			end

			SafeRemoveEntityDelayed(rag, ragLife)
		end
	elseif gib then
		local ed = EffectData()
		ed:SetOrigin(self:WorldSpaceCenter())
		ed:SetNormal(Vector(0, 0, 1))
		util.Effect("BloodImpact", ed, true, true)
	end

	SafeRemoveEntity(self)
end
